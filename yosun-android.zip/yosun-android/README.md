# yosun

Android app project made by Site to APK. It shows your website from the app's own files, so it works offline for local content.

- App name: yosun
- Package ID: com.webapp.yosun
- Version: 1.0

## Get the APK with GitHub (free)

1. Create an empty repository on GitHub.
2. Upload this folder to it (git push, or drag the folder into the upload page on a computer).
3. Open the Actions tab and wait for "Build APK" to finish.
4. Open the run, download the "apk" artifact, unzip it and install app-debug.apk.

## Build on a computer instead

Install Android Studio (or JDK 17, the Android SDK and Gradle 8.5), open this folder and run:

    gradle assembleDebug

The APK appears in app/build/outputs/apk/debug/.

## Change the website

Edit the files in app/src/main/assets/www/ and build again. The icon files are in app/src/main/res/mipmap-*/.
